# Roblox FBX Uploader — lite

A minimal mobile-friendly uploader: one HTML file + one tiny proxy server.
API-key auth only (no OAuth, no accounts, no sessions).

## Why the server exists at all

Roblox's Open Cloud API (`apis.roblox.com`) doesn't send CORS headers, so a
browser calling it directly gets blocked by the Same-Origin Policy before
your JavaScript ever sees a response — this is Roblox's server refusing
cross-origin browser requests, not something fixable from the page's own
code. `server.js` is a ~150-line relay: it takes what the browser sends,
forwards it to Roblox with the same API key, and passes the response back.
It stores nothing — no database, no session, no file on disk.

## Run it locally

```bash
npm install
npm start
```

Open `http://localhost:3000` (or your machine's LAN IP, from your phone, for
an iPhone Safari test).

## Deploy to Render (get a permanent iPhone-reachable URL)

This repo includes `render.yaml`, so Render auto-configures itself — you
just connect the repo.

1. Push this folder to a new GitHub repository (Render deploys from GitHub).
2. Go to [render.com](https://render.com) → sign up / log in → **New** →
   **Web Service**.
3. Connect your GitHub account and pick this repo. Render reads
   `render.yaml` automatically and fills in the build/start commands and
   the free plan — you shouldn't need to change anything.
4. Click **Create Web Service**. The first build takes a minute or two.
5. Once it says **Live**, open the `https://<something>.onrender.com` URL
   Render gives you — from your iPhone, that's just a normal website.

Notes on the free plan: it spins down after periods of no traffic and takes
~30–50 seconds to wake up on the next request (you'll see a loading delay,
not an error — just wait). Everything else about the app works exactly the
same as running it locally.

## Using it

1. Paste a Roblox Open Cloud API key (needs `asset:read` + `asset:write`
   permissions) and tap **Save key** — it's held in this browser tab's
   `sessionStorage` only, cleared when the tab closes, never written to the
   server.
2. Enter your Roblox **User ID** (or switch to **Group** + Group ID) — Open
   Cloud's Create Asset API requires this explicitly; it can't be inferred
   from the key alone.
3. Tap **Test connection** to confirm the key works.
4. Select an `.fbx` (≤ 20 MB), tap **Upload model**, and watch it poll the
   Roblox operation through to a real Asset ID.

## Security notes for this lean version

- The API key travels: browser → this server (over HTTPS once deployed) →
  Roblox, and is never logged or persisted anywhere in between.
- Because there's no session system, **this server has no concept of
  separate "users"** — every visitor to a deployed copy pastes their own
  key into their own browser tab, and each tab's request only ever carries
  that tab's key. Don't hardcode a key into the page or deploy it somewhere
  you don't want strangers uploading through your account's key.
- For production, put this behind HTTPS (Vercel, Render, Fly.io, etc.) so
  the key isn't sent in the clear between the phone and the server.
- No OAuth here — that needs real server-side session storage. If you want
  OAuth back, the fuller version (with express-session + OAuth) handles
  that; ask and I'll merge it into this build instead.

## Known Open Cloud limitation

There's no dedicated "is this key valid" endpoint, so **Test connection**
probes `GET /v1/assets/0` (a nonexistent asset ID): Roblox checks auth
before the lookup, so a `401` means the key is invalid and anything else
means it authenticated. See the comment above that route in `server.js`.

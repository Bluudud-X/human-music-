// server.js — minimal Roblox Open Cloud proxy
//
// Why this exists: browsers can't call apis.roblox.com directly (Roblox's
// servers don't send CORS headers, so the browser blocks it before your
// JS ever sees a response). This tiny server just relays each request.
//
// What it deliberately does NOT do, to keep it lean:
// - No sessions, no database, no login system.
// - The API key is never written to disk, a database, or a log — it lives
//   only in this request's memory for the few milliseconds it takes to
//   forward it to Roblox, then it's gone.
// - No OAuth (OAuth needs a server that remembers you between requests —
//   i.e. real sessions — which this stateless version intentionally skips).
//
// The API key itself still lives in the browser tab (sessionStorage) on the
// person's own device, exactly like it would with any tool that asks you to
// paste in a personal API key. Don't deploy this somewhere multiple
// strangers can reach with a key already filled in — each visitor should
// paste their own key.

const express = require('express');
const multer = require('multer');

const PORT = process.env.PORT || 3000;
const ROBLOX_ASSETS_BASE = 'https://apis.roblox.com/assets/v1';
const MAX_FILE_SIZE_BYTES = 20 * 1024 * 1024; // 20 MB

const app = express();
app.use(express.static('public'));

async function robloxFetch(url, options) {
  const res = await fetch(url, options);
  const text = await res.text();
  let body;
  try {
    body = text ? JSON.parse(text) : null;
  } catch {
    body = text;
  }
  return { ok: res.ok, status: res.status, body };
}

function getApiKey(req) {
  const key = req.get('x-api-key');
  return typeof key === 'string' && key.trim().length >= 10 ? key.trim() : null;
}

// ---------------------------------------------------------------------------
// Test connection
// ---------------------------------------------------------------------------

app.post('/api/test', async (req, res) => {
  const apiKey = getApiKey(req);
  if (!apiKey) return res.status(400).json({ error: 'The API key could not be verified.' });

  try {
    // Roblox has no dedicated "validate key" endpoint. Probing a nonexistent
    // asset works because Roblox checks auth BEFORE the lookup: a 401 means
    // the key itself is bad; any other status means it authenticated fine.
    const { status } = await robloxFetch(`${ROBLOX_ASSETS_BASE}/assets/0`, {
      headers: { 'x-api-key': apiKey },
    });
    if (status === 401) {
      return res.json({ success: false, message: 'The API key could not be verified.' });
    }
    return res.json({ success: true, message: 'Connection successful.' });
  } catch (err) {
    console.error('Test connection failed:', err.message);
    return res.status(502).json({ error: 'Could not reach Roblox. Try again.' });
  }
});

// ---------------------------------------------------------------------------
// Upload
// ---------------------------------------------------------------------------

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_SIZE_BYTES },
  fileFilter: (req, file, cb) => {
    if (!file.originalname.toLowerCase().endsWith('.fbx')) {
      cb(new Error('ONLY_FBX'));
      return;
    }
    cb(null, true);
  },
});

app.post('/api/upload', (req, res) => {
  upload.single('file')(req, res, async (multerErr) => {
    if (multerErr) {
      if (multerErr.code === 'LIMIT_FILE_SIZE') {
        return res.status(400).json({ error: 'This file is larger than the 20 MB limit.' });
      }
      if (multerErr.message === 'ONLY_FBX') {
        return res.status(400).json({ error: 'Only .fbx files are supported.' });
      }
      return res.status(400).json({ error: 'Could not read the uploaded file.' });
    }

    const apiKey = getApiKey(req);
    if (!apiKey) return res.status(401).json({ error: 'Please enter an API key before uploading.' });
    if (!req.file) return res.status(400).json({ error: 'Please select an FBX file first.' });

    const { creatorId, creatorType, displayName, description } = req.body || {};
    if (!creatorId) {
      return res.status(400).json({ error: 'Add your Roblox User ID (or Group ID) first.' });
    }

    try {
      const requestPayload = {
        assetType: 'Model',
        displayName: (displayName || req.file.originalname.replace(/\.fbx$/i, '')).slice(0, 50),
        description: (description || '').slice(0, 1000),
        creationContext: {
          creator: creatorType === 'group' ? { groupId: creatorId } : { userId: creatorId },
        },
      };

      const form = new FormData();
      form.set('request', JSON.stringify(requestPayload));
      form.set('fileContent', new Blob([req.file.buffer], { type: 'model/fbx' }), req.file.originalname);

      const { ok, status, body } = await robloxFetch(`${ROBLOX_ASSETS_BASE}/assets`, {
        method: 'POST',
        headers: { 'x-api-key': apiKey },
        body: form,
      });

      if (!ok || !body?.path) {
        console.error('Roblox upload rejected, status', status);
        return res.status(502).json({ error: 'Roblox rejected the upload request.' });
      }

      res.json({ ok: true, operationPath: body.path });
    } catch (err) {
      console.error('Upload error:', err.message);
      res.status(502).json({ error: 'The upload could not reach Roblox. Check your connection and try again.' });
    }
  });
});

// ---------------------------------------------------------------------------
// Operation polling
// ---------------------------------------------------------------------------

app.get('/api/operations/:operationId', async (req, res) => {
  const apiKey = getApiKey(req);
  if (!apiKey) return res.status(401).json({ error: 'Please enter an API key before uploading.' });

  const { operationId } = req.params;
  if (!/^[A-Za-z0-9_-]+$/.test(operationId)) {
    return res.status(400).json({ error: 'Invalid operation reference.' });
  }

  try {
    const { ok, body } = await robloxFetch(
      `${ROBLOX_ASSETS_BASE}/operations/${encodeURIComponent(operationId)}`,
      { headers: { 'x-api-key': apiKey } }
    );
    if (!ok) return res.status(502).json({ error: 'Roblox rejected the operation status request.' });

    res.json({
      done: Boolean(body?.done),
      error: body?.error || null,
      assetId: body?.response?.assetId || null,
    });
  } catch (err) {
    console.error('Poll error:', err.message);
    res.status(502).json({ error: 'The upload could not reach the server. Check your connection and try again.' });
  }
});

app.listen(PORT, () => {
  console.log(`Roblox FBX Uploader (lite) listening on http://localhost:${PORT}`);
});
